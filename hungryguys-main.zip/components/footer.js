export default function Footer() {
  return (
    <footer className="text-center p-3" >
      <span>©Copyright Natanael</span>
    </footer>
  );
}
